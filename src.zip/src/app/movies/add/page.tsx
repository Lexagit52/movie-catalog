// src/app/movies/add/page.tsx

'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { useMoviesStore } from '@/app/store/useMoviesStore';

export default function AddMoviePage() {
  const router = useRouter();
  const addMovie = useMoviesStore((state) => state.addMovie);

  const [title, setTitle] = useState('');
  const [year, setYear] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !year) return;

    addMovie({
      id: Date.now(), // number
      title,
      year: parseInt(year), // ✅ преобразуем string -> number
    });

    router.push('/movies');
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Добавить фильм</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block font-semibold">Название</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full border px-3 py-2 rounded"
          />
        </div>
        <div>
          <label className="block font-semibold">Год</label>
          <input
            type="number"
            value={year}
            onChange={(e) => setYear(e.target.value)}
            className="w-full border px-3 py-2 rounded"
          />
        </div>
        <button
          type="submit"
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          Добавить
        </button>
      </form>
    </div>
  );
}
